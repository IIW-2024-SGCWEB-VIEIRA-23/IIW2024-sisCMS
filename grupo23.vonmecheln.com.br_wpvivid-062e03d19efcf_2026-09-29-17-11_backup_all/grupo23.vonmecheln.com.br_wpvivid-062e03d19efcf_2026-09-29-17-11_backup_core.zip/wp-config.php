<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u684563155_Qsz9B' );

/** Database username */
define( 'DB_USER', 'u684563155_DDn7M' );

/** Database password */
define( 'DB_PASSWORD', '?,q0kdgB\\Y' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '>[*HL/(u#1PW-JCTM[IW=-`bR?aRzl1fBl~i0CD(I ]@CX!gCEeyJ9Cbl oLg>_n' );
define( 'SECURE_AUTH_KEY',   '_.^U7zd/lTpS].+MLsuse;@o?$N4(h Vs>$4ZXnwR_Ls#7))=lo0|wp^RnHGQQ8Y' );
define( 'LOGGED_IN_KEY',     'C`9q6(Cafk$Iy~l.;V;^3qvn)68dO%-O5l^Jli8DcvQw5+xz8pIS>qW8Xh2^W|SP' );
define( 'NONCE_KEY',         '|ntW?v=Lf>hO8,heXk}BLX xK=dn31<+!:s}MS+v;B($f|fvN8Y`p;O7Qss*AYl[' );
define( 'AUTH_SALT',         'Hay5?PLyF]oe!vy,2JYHg89.3Yi(Sa9/1*_)#7@!6%TtRhu(J<x<BI@K=39oVMQe' );
define( 'SECURE_AUTH_SALT',  'Nv&+c6&2D+FS-raH7 %h$J/X*5Y3V5BlKzxiZ5=l(6LXR#4.VyP7Zh^laa{6Ex=E' );
define( 'LOGGED_IN_SALT',    'ev9p5]j;gL4tg~(oUO:}O/}S@1}#9T[T0aZjo~N&Z:pa|uLGmY}!Hk?a6DPM`LYt' );
define( 'NONCE_SALT',        'IDw$lCyhnAURhXw:70<dt7cxH|YhqpIi`s7D9dpVj)@OP&F9n`@$p?t4Mv2/9pgM' );
define( 'WP_CACHE_KEY_SALT', 'PiO04Gv$eO&-a:t{+TZ|Z>cBAiQ0%ViohBJi#vUL_ %M%Wp.>.}gN:23velHUpb8' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'FS_METHOD', 'direct' );
define( 'COOKIEHASH', 'c7d550ccec15425a951b221071f54fa5' );
define( 'WP_AUTO_UPDATE_CORE', 'minor' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
